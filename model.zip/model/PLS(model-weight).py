# 仅在训练集内部优化 PLS 主成分数
# =====================================================

cv = KFold(
    n_splits=5,
    shuffle=True,
    random_state=RANDOM_STATE
)

max_components = min(
    10,
    X_train.shape[1],
    X_train.shape[0] - 1
)

cv_results = []

for n_components in range(1, max_components + 1):

    model = PLSRegression(
        n_components=n_components,
        scale=True
    )

    y_cv_pred = cross_val_predict(
        model,
        X_train,
        y_train,
        cv=cv
    ).ravel()

    cv_r2 = r2_score(y_train, y_cv_pred)
    cv_rmse = np.sqrt(
        mean_squared_error(y_train, y_cv_pred)
    )

    cv_results.append({
        'n_components': n_components,
        'CV_R2': cv_r2,
        'CV_RMSE': cv_rmse
    })

cv_results = pd.DataFrame(cv_results)

# 使用最低 RMSECV 确定最佳主成分数量
optimal_components = int(
    cv_results.loc[
        cv_results['CV_RMSE'].idxmin(),
        'n_components'
    ]
)

print(cv_results)
print(f'Optimal number of components: {optimal_components}')

# =====================================================
#使用训练集建立最终模型
# =====================================================

final_model = PLSRegression(
    n_components=optimal_components,
    scale=True
)

final_model.fit(X_train, y_train)
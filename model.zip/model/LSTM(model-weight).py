#构建LSTM模型
# =====================================

class LSTMModel(nn.Module):

    def __init__(self):

        super(LSTMModel, self).__init__()

        self.lstm = nn.LSTM(
            input_size=1,
            hidden_size=128,
            num_layers=2,
            batch_first=True
        )

        self.fc = nn.Linear(128, 1)

    def forward(self, x):

        out, _ = self.lstm(x)

        # 取最后一个时间步
        out = out[:, -1, :]

        out = self.fc(out)

        return out

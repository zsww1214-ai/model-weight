class MultiModalDensityNet(nn.Module):
    def __init__(self, input_spectral_dim=15, input_struct_dim=2, num_periods=8):
        super().__init__()

        # 分支1：高光谱特征提取（Transformer编码器）
        self.spectral_encoder = nn.TransformerEncoder(
            nn.TransformerEncoderLayer(d_model=64, nhead=8, batch_first=True),
            num_layers=2
        )
        self.spectral_proj = nn.Linear(input_spectral_dim, 64)

        # 分支2：结构化特征提取
        self.struct_net = nn.Sequential(
            nn.Linear(input_struct_dim, 16),
            nn.BatchNorm1d(16),
            nn.ReLU()
        )

        # 生育期嵌入层（将独热编码转换为低维向量）
        self.period_embed = nn.Embedding(num_periods, 8)

        # 时间序列融合（Transformer解码器）
        self.transformer_decoder = nn.TransformerDecoder(
            nn.TransformerDecoderLayer(d_model=88, nhead=8, batch_first=True),  # 新增
            num_layers=2
        )
        # ==== 修改1：将注意力层设为实例属性 ====
        self.attention = nn.Sequential(
            nn.Linear(64 + 16 + 8, 32),
            nn.ReLU(),
            nn.Linear(32, 3),
            nn.Softmax(dim=1)
        )

        # 回归预测层
        self.final_reg = nn.Sequential(
            nn.Linear(88, 32),
            nn.ReLU(),
            nn.Linear(32, 1)
        )